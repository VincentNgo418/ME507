var searchData=
[
  ['intensity_5fvalue_0',['intensity_value',['../main_8h.html#a4d3d8bf9230cbc302d5d00587312141c',1,'main.cpp']]]
];
