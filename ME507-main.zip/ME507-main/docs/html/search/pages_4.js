var searchData=
[
  ['features_20and_20control_20modes_0',['Key Features and Control Modes',['../index.html#features_sec',1,'']]],
  ['file_20structure_1',['Project File Structure',['../index.html#file_structure',1,'']]]
];
