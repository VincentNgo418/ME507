var searchData=
[
  ['regex_5ft_0',['regex_t',['../structregex__t.html',1,'']]]
];
