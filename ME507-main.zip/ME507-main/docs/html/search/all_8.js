var searchData=
[
  ['key_20features_20and_20control_20modes_0',['Key Features and Control Modes',['../index.html#features_sec',1,'']]]
];
