var searchData=
[
  ['main_2eh_0',['main.h',['../main_8h.html',1,'']]],
  ['modes_1',['Key Features and Control Modes',['../index.html#features_sec',1,'']]],
  ['modules_2',['Software Modules',['../index.html#software_modules_sec',1,'']]],
  ['motor_3',['motor',['../structmotor.html',1,'']]],
  ['motor_5fd_4',['motor_d',['../structmotor__d.html',1,'']]],
  ['my_5fstruct_5',['my_struct',['../structmy__struct.html',1,'']]]
];
