var searchData=
[
  ['modes_0',['Key Features and Control Modes',['../index.html#features_sec',1,'']]],
  ['modules_1',['Software Modules',['../index.html#software_modules_sec',1,'']]]
];
