var searchData=
[
  ['and_20build_0',['Setup and Build',['../index.html#setup_sec',1,'']]],
  ['and_20control_20modes_1',['Key Features and Control Modes',['../index.html#features_sec',1,'']]]
];
