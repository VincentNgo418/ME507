var searchData=
[
  ['components_0',['Hardware Components',['../index.html#components_sec',1,'']]],
  ['control_20modes_1',['Key Features and Control Modes',['../index.html#features_sec',1,'']]],
  ['control_20system_20documentation_2',['Ping Pong Robot Control System Documentation',['../index.html',1,'']]],
  ['controller_3',['controller',['../structcontroller.html',1,'']]]
];
