var searchData=
[
  ['setup_20and_20build_0',['Setup and Build',['../index.html#setup_sec',1,'']]],
  ['software_20modules_1',['Software Modules',['../index.html#software_modules_sec',1,'']]],
  ['structure_2',['Project File Structure',['../index.html#file_structure',1,'']]],
  ['system_20documentation_3',['Ping Pong Robot Control System Documentation',['../index.html',1,'']]]
];
