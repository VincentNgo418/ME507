var main_8h =
[
    [ "my_struct", "structmy__struct.html", null ],
    [ "Error_Handler", "main_8h.html#a1730ffe1e560465665eb47d9264826f9", null ],
    [ "distance_cm", "main_8h.html#ae021034a15c38ec3070fe51cd52b2719", null ],
    [ "heading", "main_8h.html#a049382970fbae2e500ec960a4b731e94", null ],
    [ "intensity_value", "main_8h.html#a4d3d8bf9230cbc302d5d00587312141c", null ]
];