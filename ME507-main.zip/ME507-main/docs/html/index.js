var index =
[
    [ "Introduction", "index.html#intro_sec", null ],
    [ "Key Features and Control Modes", "index.html#features_sec", null ],
    [ "Hardware Components", "index.html#components_sec", null ],
    [ "Software Modules", "index.html#software_modules_sec", null ],
    [ "Setup and Build", "index.html#setup_sec", [
      [ "Project File Structure", "index.html#file_structure", null ]
    ] ],
    [ "Quick Links", "index.html#quick_links", null ]
];